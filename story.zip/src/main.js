import Vue from 'vue'
import App from './App.vue'
import VueRouter from 'vue-router'
import 'materialize-css/dist/css/materialize.min.css'
// import 'materialize-css/dist/js/materialize.min.js'
import './font/flaticon.css'
import Home from './components/Home'
import Search from './components/Search'
import Story from './components/Story'
import Women from './components/Women'
import Diary from './components/Diary'
import Post from './components/Post'
import Page from './components/Page'
import Contact from './components/Contact'

Vue.use(VueRouter)

const router = new VueRouter({
	routes: [
		{ path:'/search', name:'Search', component: Search},
		{ path:'/story/:id', name:'Story', component: Story},
		{ path:'/women', name:'Women', component: Women},
		{ path:'/diary', name:'Diary', component: Diary},
		{ path:'/contact', name:'Contact', component: Contact},
		{ path: '/', name:'Home', component: Home},
		{ path: '/post/:id', name: 'Post', component: Post},
		{ path: '/page/:id', name: 'Page', component: Page}
	]
})

Vue.filter('datestring', function (value) {
	var v = new Date(value);
  return v.toDateString();
})

new Vue({
  el: '#app',
  router: router,
  render: h => h(App)
})
