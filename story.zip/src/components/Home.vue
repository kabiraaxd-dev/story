<template>
  <div class="home">
    <div class="category blue lighten-5 z-depth-1">
      <div class="select">
        <label for="category">Select Category</label>
        <select class="browser-default blue-text text-darken-3" v-model="category" v-on:change="catDetail()" name="category">
          <option value="" selected>Select Category</option>
          <option v-for="item in categories" v-bind:value="item.id" v-bind:key="item.id">{{item.name}} ({{item.count}})</option>
        </select>
      </div>
    </div>
    <div class="home-tabs white z-depth-1">
      <ul>
        <li><a href="#" v-on:click="tab1=true,tab2=false,tab3=false" v-bind:class="{'active':tab1}">Recent Stories</a></li>
        <li><a href="#" v-on:click="tab1=false,tab2=true,tab3=false" v-bind:class="{'active':tab2}">Recent Interviews</a></li>
        <li><a href="#" v-on:click="tab1=false,tab2=false,tab3=true" v-bind:class="{'active':tab3}">Diary</a></li>
      </ul>
    </div>
    <div v-bind:key="tab1" v-show="tab1" >
      
        <div class="home-tab-content" >
          <div class="card horizontal" v-for="item in posts" v-bind:id="item.id" v-bind:key="item.id">
            <div class="card-stacked">
              <div class="card-content ">
                <h6 class="card-title " ><router-link v-html="item.title.rendered" v-bind:to="'/post/'+item.id" class="blue-text text-darken-4"></router-link></h6>
                <div class="grey-text text-darken-1 excerpt" v-html="item.excerpt.rendered"></div>
                <div class="meta grey-text">
                  <span class="text"><i class=" flaticon-user-1 blue-text text-darken-2">
    </i> {{featuredMedia(item._embedded).author}}</span> <span class="text" ><i class=" flaticon-calendar blue-text text-darken-2"></i> {{ item.date | datestring}}</span>
                </div>
                <div class="card-action">
                  <router-link v-bind:to="'/post/'+item.id">Read More</router-link>
                </div>
              </div>
            </div>
            <div class="card-image" v-bind:style="{'position':'relative', 'background-image': 'url('+ featuredMedia(item._embedded).media +')'}">
              <router-link v-bind:to="'/post/'+item.id">&nbsp;</router-link>
              <!-- <img v-bind:src="featuredMedia(item._embedded).media" > -->
            </div>
          </div>
        
      </div>
    </div>
    <div v-show="tab2">
      <div class="home-tab-content">
          <div class="card horizontal" v-for="item in interviews" v-bind:id="item.id" v-bind:key="item.id">
            <div class="card-stacked">
              <div class="card-content ">
                <h6 class="card-title " ><router-link v-bind:to="'/post/'+item.id" v-html="item.title.rendered" class="blue-text text-darken-4"></router-link></h6>
                <div class="grey-text text-darken-1 excerpt" v-html="item.excerpt.rendered"></div>
                <div class="meta grey-text">
                  <span class="text"><i class=" flaticon-user-1 blue-text text-darken-2">
    </i> {{featuredMedia(item._embedded).author}}</span> <span class="text" ><i class=" flaticon-calendar blue-text text-darken-2"></i> {{ item.date | datestring}}</span>
                </div>
                <div class="card-action">
                  <router-link v-bind:to="'/post/'+item.id">Read More</router-link>
                </div>
              </div>
            </div>
            <div class="card-image" v-bind:style="{'position':'relative', 'background-image': 'url('+ featuredMedia(item._embedded).media +')'}">
              <router-link v-bind:to="'/post/'+item.id">&nbsp;</router-link>
              <!-- <img v-bind:src="featuredMedia(item._embedded).media" > -->
            </div>
          </div>
         
      </div>
    </div>
    <div v-show="tab3">
      <div class="home-tab-content">
          <div class="card horizontal" v-for="item in diary" v-bind:id="item.id" v-bind:key="item.id">
            <div class="card-stacked">
              <div class="card-content ">
                <h6 class="card-title " ><router-link v-bind:to="'/post/'+item.id" v-html="item.title.rendered" class="blue-text text-darken-4"></router-link></h6>
                <div class="grey-text text-darken-1 excerpt" v-html="item.excerpt.rendered"></div>
                <div class="meta grey-text">
                  <span class="text"><i class=" flaticon-user-1 blue-text text-darken-2">
    </i> {{featuredMedia(item._embedded).author}}</span> <span class="text" ><i class=" flaticon-calendar blue-text text-darken-2"></i> {{ item.date | datestring}}</span>
                </div>
                <div class="card-action">
                  <router-link v-bind:to="'/post/'+item.id">Read More</router-link>
                </div>
              </div>
            </div>
            <div class="card-image" v-bind:style="{'position':'relative', 'background-image': 'url('+ featuredMedia(item._embedded).media +')'}">
              <router-link v-bind:to="'/post/'+item.id">&nbsp;</router-link>
              <!-- <img v-bind:src="featuredMedia(item._embedded).media" > -->
            </div>
          </div>
         
      </div>
    </div>

  </div>
</template>
<script>
import axios from 'axios'
export default {
  data: function() {
    return {
      name: "",
      categories: [],
      category: "",
      catdetail: "",
      posts: [],
      interviews:[],
      diary:[],
      tab1: true,
      tab2: false,
      tab3: false,
      headers: [],
      perpage: 10,
      currentpage: 1,
      errors: []
    }
  },
  mounted: function() {

    /*fetch recent*/
    if (window.sessionStorage.getItem('recent')) {
      this.posts = JSON.parse(window.sessionStorage.getItem('recent'));
    }else{
      this.$emit('back',false);
      this.$emit('loading',true);
      /*fetch recent*/
      axios.get('http://www.tellmeastorymom.com/wp-json/wp/v2/posts?_embed&page=' + this.currentpage + '&per_page=' + this.perpage)
      .then(response => {
        /*console.log(response);*/
        this.posts = response.data
        this.headers = response.headers;
        window.sessionStorage.setItem('recent', JSON.stringify(response.data));
        for (var k in this.headers) {
          if (k == 'x-wp-total') {
            this.totalposts = Number(this.headers[k]);
          } else if (k == 'x-wp-totalpages') {
            this.totalpages = Number(this.headers[k]);
          }
        }
      })
      .catch(e => { this.errors.push(e) })
      .then(()=>{
        this.$emit('loading',false);
      });
    }

    /*fetch interview*/
    if (window.sessionStorage.getItem('women')) {
      this.interviews = JSON.parse(window.sessionStorage.getItem('women'));
    }else{
      /*fetch interview*/
      axios.get('http://www.tellmeastorymom.com/wp-json/wp/v2/posts?_embed&categories=248')
      .then(response => {
        /*console.log(response);*/
        this.interviews = response.data;
        window.sessionStorage.setItem('women',JSON.stringify(response.data));
      })
      .catch(e => { this.errors.push(e) });
    }

    /*fetch diary*/
    if (window.sessionStorage.getItem('diary')) {
      this.diary = JSON.parse(window.sessionStorage.getItem('diary'));
    }else{
      /*fetch interview*/
      axios.get('http://www.tellmeastorymom.com/wp-json/wp/v2/posts?_embed&categories=347')
      .then(response => {
        /*console.log(response);*/
        this.diary = response.data;
        window.sessionStorage.setItem('diary',JSON.stringify(response.data));
      })
      .catch(e => { this.errors.push(e) });
    }

    /*fetch categories*/
    if (window.sessionStorage.getItem('categories')) {
      this.categories = JSON.parse(window.sessionStorage.getItem('categories'));
    } else {
      axios.get('http://www.tellmeastorymom.com/wp-json/wp/v2/categories?orderby=count&order=desc&per_page=50')
      .then(response => {
        // console.log(response.data);
        this.categories = response.data;
        window.sessionStorage.setItem('categories', JSON.stringify(response.data));
      })
      .catch(e => { this.errors.push(e) });
    }
    
    this.$emit('back', false);
  },
  methods: {
    featuredMedia: function(data) {
      // console.log(data);
      var newobj = {};
      for (var k in data) {
        newobj[k.replace(":", "")] = data[k];
      }
      // console.log(newobj);
      var returnobj = {};

      function category(loopobject) {
        var output = [];
        for (var i = 0; i < loopobject.length; i++) {
          output.push(loopobject[i].name);
        }
        return output;
      }
      /*returnobj.media = newobj.wpfeaturedmedia[0].media_details.sizes.medium.source_url;*/
      returnobj.media = (newobj.wpfeaturedmedia)?(newobj.wpfeaturedmedia[0].source_url):'dist/noimage.jpg';
      returnobj.category = category(newobj.wpterm[0]); //newobj.wpterm[0][0].name;
      returnobj.tags = category(newobj.wpterm[1]); //[0].name;
      returnobj.author = newobj.author[0].name;

      // console.log(returnobj);
      return returnobj;
    },
    catDetail: function() {
      this.$router.push('/story/'+this.category);
    }
  }
}

</script>
<style>
.home {
  padding: 0;
}

.category {
  margin-bottom: 0;
}

.category .select {
  width: 90%;
  max-width: 400px;
  margin: auto;
  text-align: center;
  display: flex;
  justify-content: center;
  align-items: center;
}
.category select {
  border: 0 none;
  text-transform: uppercase;
  text-align: center;
  font-weight: 600;
  background: none transparent;
}

.category select:focus {
  outline: none;
}

.home-tab-content { padding-left: 10px; padding-right: 10px;}
.home-tabs ul {
  list-style: none;
  margin: 0;
  padding: 0;
  display: -webkit-flex;
  display: -moz-flex;
  display: -ms-flex;
  display: -o-flex;
  display: flex;
  justify-content: center;
}

.home-tabs ul li {}

.home-tabs ul li a {
  display: block;
  padding: 10px 12px;
  text-decoration: none;
  text-align: center;
  position: relative;
  color: grey;
}
.home-tabs ul li a.active { color: #263a7e; }

.home-tabs ul li a:before {
  content: '';
  border-left: 1px solid #2460a2;
  position: absolute;
  left: 0;
  top: 25%;
  height: 50%;
}

.home-tabs ul li:first-child a:before {
  border-left: 0 none;
}

.home .card .card-action,
.search .card .card-action {
  padding: 0;
}

.home .card .card-action a,
.search .card .card-action a {
  font-size: 0.85em;
}

.home .card.horizontal .card-stacked,
.search .card.horizontal .card-stacked {
  flex: 2;
}

.home .card.horizontal .card-content,
.search .card.horizontal .card-content {
  padding: 5px 10px;
  font-size: 14px;
}

.card-content .excerpt {
  word-break: break-word;
  text-align: justify;
  max-height: 3.6em;
  overflow: hidden;
}

.home .card.horizontal .card-title,
.search .card.horizontal .card-title {
  font-size: 1em;
  margin-top: 3px;
  margin-bottom: 2px;
  line-height: 1.25;
  font-weight: 500;
  text-transform: uppercase;
}

.home .card.horizontal p,
.search .card.horizontal p {
  line-height: 1.25;
  font-size: 1em;
}

.home .card.horizontal .card-image,
.search .card.horizontal .card-image {
  flex: 1;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}

.home .card.horizontal .card-image a,
.search .card.horizontal .card-image a { display: block; height: 100%; }

.home .card.horizontal .meta,
.search .card.horizontal .meta {
  font-size: 0.75em;
  padding-top: 6px;
}

.home .card.horizontal .meta .material-icons,
.search .card.horizontal .meta .material-icons {
  vertical-align: middle;
}

.home .card.horizontal .meta span,
.search .card.horizontal .meta span {
  line-height: 1.5;
}

.home .card.horizontal .meta span:first-child,
.search .card.horizontal .meta span:first-child {
  margin-right: 10px;
}

</style>
