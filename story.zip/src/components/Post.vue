<template>
  <div class="search post">
    <!-- <h6 class="center-align page-title">{{name}}</h6> -->
    <div class="flex textsize z-depth-1">
      <button v-bind:class="{'white-text orange':textSize=='0.9'}" class="waves-effect" v-on:click="fontSize(0.9)">A</button>
      <button v-bind:class="{'white-text orange':textSize=='1.1'}" class="waves-effect" v-on:click="fontSize(1.1)">A</button>
      <button v-bind:class="{'white-text orange':textSize=='1.25'}" class="waves-effect" v-on:click="fontSize(1.25)">A</button>
    </div>
    <h5 class="head blue-text text-darken-4" v-html="post.title.rendered"></h5>
    <div class="row">
      <div class="col s6 ">
        <span class="grey-text" ><i class="flaticon-user blue-text"></i> {{featuredMedia(post._embedded).author}}</span></div>
      <div class="col s6"><span class="grey-text" ><i class="flaticon-calendar blue-text"></i> {{post.date | datestring}}</span></div>
    </div>
    <div class="image">
      <img v-bind:src="featuredMedia(post._embedded).media" class="responsive-img" >
            </div>
      <div class="card-content grey-text text-darken-2">
        <div v-html="post.content.rendered" v-bind:style="{fontSize:textSize+'em'}"></div>
      </div>
      <div class="card-meta">
        <i class="flaticon-price-tag"></i> Tagged: <span v-for="(value, index) in featuredMedia(post._embedded).tags" v-bind:key="index" class="badge light-blue accent-1" >{{value}} </span>
        <hr>
        <i class="flaticon-grid"></i> Posted in: <span v-for="(value, index) in featuredMedia(post._embedded).category" v-bind:key="index" class="badge  lime accent-1">{{value}} </span>
      </div>
    </div>
</template>
<script>
import axios from 'axios'
export default {
  data: function() {
    return {
      name: "Post",
      id: '',
      post: [],
      errors: [],
      textSize:1.1
    }
  },
  mounted: function() {
    this.$emit('back',true);
    this.$emit('loading',true);
    /*fetch post detail*/
    axios.get('http://www.tellmeastorymom.com/wp-json/wp/v2/posts/' + this.$route.params.id + '/?_embed')
      .then(response => {
        // console.log(response.data);
        this.post = response.data;
      })
      .catch(e => { this.errors.push(e) })
      .then(()=>{
        this.$emit('loading',false);
      });
  },
  methods: {
    featuredMedia: function(data) {
      // console.log(data);
      var newobj = {};
      for (var k in data) {
        newobj[k.replace(":", "")] = data[k];
      }
      // console.log(newobj);
      var returnobj = {};

      function category(loopobject) {
        var output = [];
        for (var i = 0; i < loopobject.length; i++) {
          output.push(loopobject[i].name);
        }
        return output;
      }
      returnobj.media = (newobj.wpfeaturedmedia)?(newobj.wpfeaturedmedia[0].source_url):'dist/post-place.jpg';
      returnobj.category = category(newobj.wpterm[0]); //newobj.wpterm[0][0].name;
      returnobj.tags = category(newobj.wpterm[1]); //[0].name;
      returnobj.author = newobj.author[0].name;

      // console.log(returnobj);
      return returnobj;
    },
    fontSize: function (argument) {
      this.textSize = argument;
    }
  }
}

</script>
<style>
.flex { display: -webkit-flex;display: -moz-flex;display: -ms-flex;display: -o-flex;display: flex;}
.textsize { float:right; background:white; font-size: 14px; margin-top: -1.05rem; position: sticky; top: 56px; right: 0;}
.textsize button {background: none; padding:0.5em 0.75em; border:0 none; font-size: 1.1em; min-width:36px; }
.textsize button:nth-child(1) {font-size: 0.9em; }
.textsize button:nth-child(3) {font-size: 1.25em; }
.post {padding: 0;}
.post .head {
  padding: 10px 10px 0;
}

.post .card-content {
  padding: 5px 10px;
  word-break: break-word;
}

.post .card-content p {
  margin-top: 0;
}

.post .card-content * {
  margin-left: 0;
  margin-right: 0;
  padding-left: 0;
  padding-right: 0;
}
.post .card-content blockquote {
  padding-left: 10px;
}
.post .card-content img {
  max-width: 100%;
  height: auto;
}
.post .card-content h1 {
  font-size: 2em;
}
.post .card-content h2 {
  font-size: 1.5em;
}
.post .card-content h3 {
  font-size: 1.25em;
}
.post .card-content h4 {
  font-size: 1.125em;
}
.post .card-meta {
  padding: 10px;
}

.post .card-meta span {
  float: none;
  margin-left: 4px;
  display: inline-block;
  margin-bottom:4px;
  border-radius: 4px;
}

</style>
